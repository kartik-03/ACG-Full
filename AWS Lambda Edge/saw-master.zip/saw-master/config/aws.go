package config

type AWSConfiguration struct {
	Region  string
	Profile string
}
