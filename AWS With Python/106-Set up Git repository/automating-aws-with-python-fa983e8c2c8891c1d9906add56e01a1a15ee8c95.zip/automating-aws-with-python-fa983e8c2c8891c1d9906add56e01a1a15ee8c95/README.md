# Automating AWS with Python

Repository for the A Cloud Guru course *Automating AWS with Python*
