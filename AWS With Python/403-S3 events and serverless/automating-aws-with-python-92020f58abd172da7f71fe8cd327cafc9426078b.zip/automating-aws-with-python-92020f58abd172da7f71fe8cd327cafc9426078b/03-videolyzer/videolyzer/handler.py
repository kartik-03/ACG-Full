def start_processing_video(event, context):
    print(event)

    return
    
